#pragma once

#include <string>
#include <fstream>

struct Storable {
	int test;
	virtual void encode(std::ofstream& file) = 0;
	virtual void encodeWithClassName(std::ofstream& file) = 0;
	virtual bool decode(const std::string& name, std::ifstream& file) = 0;
};