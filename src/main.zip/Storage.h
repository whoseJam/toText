#pragma once

#include <functional>
#include <fstream>
#include <iostream>
#include <map>

template<typename Base>
class Storage {
public:
	using PtrDecodeFunc = std::function<void(void*, std::ifstream&)>;
	using PtrEncodeFunc = std::function<void(void*, std::ofstream&)>;
	using SetFunc = std::function<void(Base*, std::ifstream&)>;
	using GetFunc = std::function<void(Base*, std::ofstream&)>;
	using Offset = unsigned int;

	template<typename T>
	struct Public {
		Public(const std::string& name, Offset off) {
			if (getInstance()->setterFunc.find(name) != 
				getInstance()->setterFunc.end()) {
				std::cout << "Error : " << name << " is Public and Setter\n";
				exit(-1);
			}
			auto decoder = [](void* ptr, std::ifstream& stream) {stream >> (*((T*)ptr)); };
			auto encoder = [](void* ptr, std::ofstream& stream) {stream << (*((T*)ptr)) << ' '; };
			getInstance()->ptrDecodeFunc[name] = decoder;
			getInstance()->ptrEncodeFunc[name] = encoder;
			getInstance()->offset[name] = off;
		}
	};

	template<typename T>
	struct Private {
		Private(const std::string& name, T(Base::* getter)(), void(Base::* setter)(T)) {
			if (getInstance()->ptrDecodeFunc.find(name) != 
				getInstance()->ptrDecodeFunc.end()) {
				std::cout << "Error : " << name << " is Public and Setter\n";
				exit(-1);
			}
			auto decoder = [=](Base* base, std::ifstream& stream) {T value; stream >> value; (base->*setter)(value); };
			auto encoder = [=](Base* base, std::ofstream& stream) {stream << (base->*getter)() << ' '; };
			getInstance()->setterFunc[name] = decoder;
			getInstance()->getterFunc[name] = encoder;
		}
	};
	bool decode(Base* base, const std::string& name, std::ifstream& stream) {
		if (decodeFromPtr(base, name, stream))return true;
		if (decodeFromSetter(base, name, stream))return true;
		return false;
	}
	void encode(Base* base, std::ofstream& stream) {
		for (auto& it : ptrEncodeFunc) {
			void* ptr = (void*)((char*)base + offset[it.first]);
			stream << it.first << ' ';
			(it.second)(ptr, stream);
		}
		for (auto& it : getterFunc) {
			stream << it.first << ' ';
			(it.second)(base, stream);
		}
	}
	static Storage* getInstance() {
		static Storage f;
		return &f;
	}
private:
	bool decodeFromPtr(void* base, const std::string& name, std::ifstream& stream) {
		if (ptrDecodeFunc.find(name) ==
			ptrDecodeFunc.end())return false;
		void* ptr = (void*)((char*)base + (offset[name]));
		ptrDecodeFunc[name](ptr, stream);
		return true;
	}
	bool decodeFromSetter(Base* base, const std::string& name, std::ifstream& stream) {
		if (setterFunc.find(name) ==
			setterFunc.end())return false;
		setterFunc[name](base, stream);
		return true;
	}
	Storage() {};
	Storage(const Storage&) = delete;
	Storage(Storage&&) = delete;
	Storage& operator=(const Storage&) = delete;
	std::map<std::string, PtrDecodeFunc> ptrDecodeFunc;
	std::map<std::string, PtrEncodeFunc> ptrEncodeFunc;
	std::map<std::string, SetFunc> setterFunc;
	std::map<std::string, GetFunc> getterFunc;
	std::map<std::string, Offset> offset;
};
