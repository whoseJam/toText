#pragma once

#include <type_traits>
#include <vector>
#include <string>
#include "Factory.h"
#include "Storable.h"
#include "Storage.h"

template<typename Base, typename T>
T getter_trait(T(Base::*)()) {
};

#define STORE_PUBLIC(Class,Value) \
	Storage<Class>::Public<decltype(Class::Value)> \
    __STORE_##Class##_##Value(#Value,offsetof(Class,Class::Value));
#define STORE_PRIVATE(Class,Value,Getter,Setter) \
	Storage<Class>::Private<decltype(getter_trait(&Class::Getter))> \
    __STORE_##Class##_##Getter_Setter \
    (#Value,&Class::Getter,&Class::Setter);
#define STORE_CHECK_SELF_LOAD_SUCCESSFUL(self) \
    if (Storage<self>::getInstance()->decode(this, name, stream)) return true;
#define STORE_CHECK_PARENT_LOAD_SUCCESSFUL(parent) \
    if (parent::decode(name, stream)) return true;
#define STORE_ENCODE_PARENT(parent) \
    parent::encode(stream);

#define STORE_ENCODE_BODY_1(self) \
    Storage<self>::getInstance()->encode(this, stream);
#define STORE_ENCODE_BODY_2(self,p0) \
    STORE_ENCODE_BODY_1(self); \
    STORE_ENCODE_PARENT(p0);
#define STORE_ENCODE_BODY_3(self,p0,p1) \
    STORE_ENCODE_BODY_2(self,p0); \
    STORE_ENCODE_PARENT(p1);
#define STORE_ENCODE_BODY_4(self,p0,p1,p2) \
    STORE_ENCODE_BODY_3(self,p0,p1); \
    STORE_ENCODE_PARENT(p2);

#define STORE_DECODE_BODY_1(self) \
    STORE_CHECK_SELF_LOAD_SUCCESSFUL(self);
#define STORE_DECODE_BODY_2(self,p0) \
    STORE_DECODE_BODY_1(self); \
    STORE_CHECK_PARENT_LOAD_SUCCESSFUL(p0);
#define STORE_DECODE_BODY_3(self,p0,p1) \
    STORE_DECODE_BODY_2(self,p0); \
    STORE_CHECK_PARENT_LOAD_SUCCESSFUL(p1);
#define STORE_DECODE_BODY_4(self,p0,p1,p2) \
    STORE_DECODE_BODY_3(self,p0,p1); \
    STORE_CHECK_PARENT_LOAD_SUCCESSFUL(p2);

#define STORE_ENCODE_CLASS(self) \
    stream << "[class]" << #self << ' '

#define STORABLE_DECLARE \
    virtual bool decode(const std::string & name, std::ifstream & stream) override; \
    virtual void encode(std::ofstream& stream) override; \
    virtual void encodeWithClassName(std::ofstream& stream) override;
#define STORABLE_DECLARE_AND_IMPL(self) \
    virtual bool decode(const std::string& name, std::ifstream& stream) override { \
        STORE_DECODE_BODY_1(self); \
        return false; \
    } \
    virtual void encode(std::ofstream& stream) override { STORE_ENCODE_BODY_1(self); } \
    virtual void encodeWithClassName(std::ofstream& stream) override { STORE_ENCODE_CLASS(self); STORE_ENCODE_BODY_1(self); }
#define STORABLE_DECLARE_AND_IMPL_1(self,p0) \
    virtual bool decode(const std::string& name, std::ifstream& stream) override { \
        STORE_DECODE_BODY_2(self,p0); \
        return false; \
    } \
    virtual void encode(std::ofstream& stream) override { STORE_ENCODE_BODY_2(self,p0); } \
    virtual void encodeWithClassName(std::ofstream& stream) override { STORE_ENCODE_CLASS(self); STORE_ENCODE_BODY_2(self,p0); }
#define STORABLE_DECLARE_AND_IMPL_2(self,p0,p1) \
    virtual bool decode(const std::string& name, std::ifstream& stream) override { \
        STORE_DECODE_BODY_3(self,p0,p1); \
        return false; \
    } \
    virtual void encode(std::ofstream& stream) override { STORE_ENCODE_BODY_3(self,p0,p1); } \
    virtual void encodeWithClassName(std::ofstream& stream) override { STORE_ENCODE_CLASS(self); STORE_ENCODE_BODY_3(self,p0,p1); }
#define STORABLE_DECLARE_AND_IMPL_3(self,p0,p1,p2) \
    virtual bool decode(const std::string& name, std::ifstream& stream) override { \
        STORE_DECODE_BODY_4(self,p0,p1,p2); \
        return false \
    } \
    virtual void encode(std::ofstream& stream) override { STORE_ENCODE_BODY_4(self,p0,p1,p2); } \
    virtual void encodeWithClassName(std::ofstream& stream) override { STORE_ENCODE_CLASS(self); STORE_ENCODE_BODY_4(self,p0,p1,p2); }

#define STORE(Class) \
    Factory<Storable>::registerClass<Class> __STORE_FACTORY_##Class(#Class)

namespace Store {
    void store(const std::string& path, std::vector<Storable*>);
    std::vector<Storable*> load(const std::string& path);
}