
#include "Store.h"
namespace Store {
	using namespace std; 
    void store(const string& path, vector<Storable*> objects) {
        ofstream output;
        output.open(path);
        for (Storable* object : objects) {
            object->encodeWithClassName(output);
            output << '\n';
        }
    }
    vector<Storable*> load(const string& path) {
        vector<Storable*> objects;
        ifstream input;
        input.open(path);

        string className;
        string name;
        input >> className;

        while (true) {
            if (input.eof()) break;
            Storable* item = Factory<Storable>::getNormalPtr(className.substr(7));
            while (true) {
                input >> name;
                if ((name.length() > 6 && name[0] == '[' && name[1] == 'c' &&
                    name[2] == 'l' && name[3] == 'a' && name[4] == 's' &&
                    name[5] == 's' && name[6] == ']') || input.eof()) {
                    objects.push_back(item);
                    break;
                }
                bool flag = item->decode(name, input);
            }
            if (input.eof()) break;
            className = name;
        }
        
        input.close();
        return objects;
    }
}
#include <string>
using namespace std;

class Pig : virtual public Storable {
public:
    int health;
    int food;
    STORABLE_DECLARE_AND_IMPL(Pig);
};
STORE_PUBLIC(Pig, health);
STORE_PUBLIC(Pig, food);
STORE(Pig);

class People : virtual public Storable {
public:
    string name;
    int age;
    STORABLE_DECLARE_AND_IMPL(People);
};
STORE_PUBLIC(People, name);
STORE_PUBLIC(People, age);
STORE(People);

class Student : public People, public Pig {
public:
    int grade;
    float getScore() { return score; }
    void setScore(float v) {score = v;}
    STORABLE_DECLARE_AND_IMPL_2(Student, People, Pig);
private:
    float score;
};
STORE_PUBLIC(Student, grade);
STORE_PRIVATE(Student, score, getScore, setScore);
STORE(Student);


int main() {
    vector<Storable*> ans = Store::load("list.txt");
    cout << "length=" << ans.size() << "\n";
    Store::store("output.txt", ans);
    return 0;
}
